export function test ( ) {
	console.log( "TEST" );
	}